
// COR DOS TEXTOS //

var text1 = document.getElementById('text1');
text1.addEventListener('mouseover', function handleMouseOver() {
  text1.style.color = 'red'
});

var text1 = document.getElementById('text1');
text1.addEventListener('mouseout', function handleMouseout() {
  text1.style.color = 'black'
});



var text2 = document.getElementById('text2');
text2.addEventListener('mouseover', function handleMouseOver() {
  text2.style.color = 'red'
});

var text2 = document.getElementById('text2');
text2.addEventListener('mouseout', function handleMouseout() {
  text2.style.color = 'black'
});


var text3 = document.getElementById('text3');
text3.addEventListener('mouseover', function handleMouseOver() {
  text3.style.color = 'red'
});

var text3 = document.getElementById('text3');
text3.addEventListener('mouseout', function handleMouseout() {
  text3.style.color = 'black'
});

var text4 = document.getElementById('text4');
text4.addEventListener('mouseover', function handleMouseOver() {
  text4.style.color = 'red'
});

var text4 = document.getElementById('text4');
text4.addEventListener('mouseout', function handleMouseout() {
  text4.style.color = 'black'
});

var text5 = document.getElementById('text5');
text5.addEventListener('mouseover', function handleMouseOver() {
  text5.style.color = 'red'
});

var text5 = document.getElementById('text5');
text5.addEventListener('mouseout', function handleMouseout() {
  text5.style.color = 'black'
});

var text6 = document.getElementById('text6');
text6.addEventListener('mouseover', function handleMouseOver() {
  text6.style.color = 'red'
});

var text6 = document.getElementById('text6');
text6.addEventListener('mouseout', function handleMouseout() {
  text6.style.color = 'black'
});

// FIM COR TEXTOS //

// BUSCAR//

var bbuscar = document.getElementById('input1');
bbuscar.addEventListener('mouseover', function handleMouseOver() {
  bbuscar.style.color = 'purple'

});

// BUSCAR //




